# Version: 1.0 - 2025-05-26 - Initial models file.
from django.db import models

# Create your models here.
# Example: Custom User Profile if needed later
# from django.contrib.auth.models import User
# class UserProfile(models.Model):
#     user = models.OneToOneField(User, on_delete=models.CASCADE)
#     # Add additional fields here
#     def __str__(self):
#         return self.user.username