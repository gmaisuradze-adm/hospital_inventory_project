# Version: 1.0 - 2025-05-26 08:06:31 UTC - gmaisuradze-adm - Initial app config.
from django.apps import AppConfig

class CoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core'