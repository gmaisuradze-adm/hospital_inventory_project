# Version: 1.1 - 2025-05-26 - Defined StockItemForm.
# User: gmaisuradze-adm
from django import forms
from .models import StockItem, StockItemCategory, StockItemSupplier # Import necessary models
from django.utils.translation import gettext_lazy as _

class StockItemForm(forms.ModelForm):
    class Meta:
        model = StockItem
        fields = [
            'item_id',
            'name',
            'description',
            'category',
            'supplier',
            'quantity_on_hand',
            'minimum_stock_level',
            'unit_price',
            'storage_location',
            'last_restocked_date',
            'expiry_date',
            'notes',
        ]
        # 'date_added' and 'last_updated' are auto-managed, so not included in the form.

        widgets = {
            'name': forms.TextInput(attrs={'placeholder': _('e.g., USB-C Cable, HP 85A Toner Cartridge')}),
            'description': forms.Textarea(attrs={'rows': 3, 'placeholder': _('Provide a brief description of the item')}),
            'item_id': forms.TextInput(attrs={'placeholder': _('e.g., SKU001, PN-XYZ789')}),
            'category': forms.Select(attrs={'class': 'form-select'}),
            'supplier': forms.Select(attrs={'class': 'form-select'}),
            'quantity_on_hand': forms.NumberInput(attrs={'min': '0'}),
            'minimum_stock_level': forms.NumberInput(attrs={'min': '0'}), # Model already has PositiveIntegerField
            'unit_price': forms.NumberInput(attrs={'step': '0.01', 'min': '0.00'}),
            'storage_location': forms.TextInput(attrs={'placeholder': _('e.g., Shelf A1, Bin 3')}),
            'last_restocked_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'expiry_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'notes': forms.Textarea(attrs={'rows': 3, 'placeholder': _('Any additional notes about the item')}),
        }

        help_texts = {
            'item_id': _("Unique identifier for the stock item (e.g., SKU, part number)."),
            'name': _("Name of the stock item."),
            'category': _("Select the category for this item."),
            'supplier': _("Select the supplier for this item."),
            'quantity_on_hand': _("Current quantity in stock. Cannot be negative."),
            'minimum_stock_level': _("Minimum quantity before reordering is needed. Cannot be negative."),
            'unit_price': _("Price per unit. Enter 0 if not applicable or free."),
            'expiry_date': _("For perishable items. Leave blank if not applicable."),
        }

        labels = {
            'item_id': _('Item ID / SKU'),
            'name': _('Item Name'),
            'description': _('Description'),
            'category': _('Category'),
            'supplier': _('Supplier'),
            'quantity_on_hand': _('Quantity on Hand'),
            'minimum_stock_level': _('Minimum Stock Level'),
            'unit_price': _('Unit Price (€)'), # Assuming Euro, adjust if needed
            'storage_location': _('Storage Location'),
            'last_restocked_date': _('Last Restocked Date'),
            'expiry_date': _('Expiry Date (if applicable)'),
            'notes': _('Additional Notes'),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Make category and supplier not required in the form if they are blank=True in model
        # (ModelForm already respects blank=True for fields, but this is for explicit clarity or if you want to change widget attributes)
        if self.fields['category'].required:
             self.fields['category'].widget.attrs.update({'class': 'form-select'})
        else:
            self.fields['category'].widget.attrs.update({'class': 'form-select'}) # Keep class even if not required

        if self.fields['supplier'].required:
            self.fields['supplier'].widget.attrs.update({'class': 'form-select'})
        else:
            self.fields['supplier'].widget.attrs.update({'class': 'form-select'}) # Keep class even if not required

        # If you want to dynamically populate choices or filter them, you can do it here.
        # For example, if StockItemCategory or StockItemSupplier have many entries:
        # self.fields['category'].queryset = StockItemCategory.objects.all().order_by('name')
        # self.fields['supplier'].queryset = StockItemSupplier.objects.all().order_by('name')
        # This is often handled by default by ModelChoiceField, but good to know.

    # You can add custom validation for the form here if needed,
    # beyond what the model's clean() method provides.
    # For example:
    # def clean_item_id(self):
    #     item_id = self.cleaned_data.get('item_id')
    #     if item_id and not item_id.isalnum(): # Example: ensure item_id is alphanumeric
    #         raise forms.ValidationError(_("Item ID must be alphanumeric."))
    #     return item_id

    # def clean(self):
    #    cleaned_data = super().clean()
    #    # Example: cross-field validation
    #    last_restocked = cleaned_data.get('last_restocked_date')
    #    expiry_date = cleaned_data.get('expiry_date')
    #    if last_restocked and expiry_date and expiry_date < last_restocked:
    #        raise forms.ValidationError(_("Expiry date cannot be before the last restocked date."))
    #    return cleaned_data
