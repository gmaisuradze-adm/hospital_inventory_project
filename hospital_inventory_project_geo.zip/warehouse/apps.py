# Version: 1.0 - 2025-05-26 - Initial app config.
from django.apps import AppConfig

class WarehouseConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'warehouse'