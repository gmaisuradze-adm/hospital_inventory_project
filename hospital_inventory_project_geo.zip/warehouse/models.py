# Version: 1.1 - 2025-05-26 - Added get_absolute_url to StockItem.
# User: gmaisuradze-adm
from django.db import models
from django.conf import settings
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _
from django.urls import reverse # Import reverse

class StockItemCategory(models.Model):
    name = models.CharField(max_length=100, unique=True, help_text="Category of the stock item (e.g., Cables, Toners, Peripherals).")
    description = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = "Stock Item Category"
        verbose_name_plural = "Stock Item Categories"
        ordering = ['name']

    def __str__(self):
        return self.name

class StockItemSupplier(models.Model):
    name = models.CharField(max_length=150, unique=True)
    contact_person = models.CharField(max_length=100, blank=True, null=True)
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    address = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = "Stock Item Supplier"
        verbose_name_plural = "Stock Item Suppliers"
        ordering = ['name']

    def __str__(self):
        return self.name

class StockItem(models.Model):
    item_id = models.CharField(max_length=50, unique=True, help_text="Unique identifier for the stock item (e.g., SKU, part number).")
    name = models.CharField(max_length=200, help_text="Name of the stock item (e.g., USB-C Cable, HP 85A Toner Cartridge).")
    description = models.TextField(blank=True, null=True)
    
    category = models.ForeignKey(StockItemCategory, on_delete=models.SET_NULL, null=True, blank=True, related_name="stock_items")
    supplier = models.ForeignKey(StockItemSupplier, on_delete=models.SET_NULL, null=True, blank=True, related_name="supplied_stock_items")
    
    quantity_on_hand = models.PositiveIntegerField(default=0, help_text="Current quantity in stock.")
    minimum_stock_level = models.PositiveIntegerField(default=1, help_text="Minimum quantity before reordering is needed.")
    
    unit_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, help_text="Price per unit.")
    
    storage_location = models.CharField(max_length=100, blank=True, null=True, help_text="Physical location in the warehouse (e.g., Shelf A1, Bin 3).")
    
    last_restocked_date = models.DateField(null=True, blank=True)
    expiry_date = models.DateField(null=True, blank=True, help_text="For perishable items.")
    
    notes = models.TextField(blank=True, null=True)
    
    date_added = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Stock Item"
        verbose_name_plural = "Stock Items"
        ordering = ['name']

    def __str__(self):
        return f"{self.name} ({self.item_id}) - Qty: {self.quantity_on_hand}"

    @property
    def is_below_minimum_stock(self):
        return self.quantity_on_hand < self.minimum_stock_level

    def clean(self):
        if self.quantity_on_hand < 0:
            raise ValidationError(_("Quantity on hand cannot be negative."))
        if self.minimum_stock_level < 0:
            raise ValidationError(_("Minimum stock level cannot be negative."))

    def get_absolute_url(self):
        # Returns the URL to access a particular instance of StockItem.
        return reverse('warehouse:stockitem_detail', kwargs={'pk': self.pk})