from django import forms
from .models import Request, RequestType, Equipment # Assuming Equipment is from inventory.models

class RequestCreateForm(forms.ModelForm):
    # Making desired_completion_date use a DateInput widget for better UX
    desired_completion_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}),
        required=False # As per model (blank=True, null=True)
    )

    # Optionally, you can customize the queryset for related_equipment
    # For example, to only show equipment that is 'in_stock' or 'in_use'
    # related_equipment = forms.ModelChoiceField(
    #     queryset=Equipment.objects.filter(status__in=['in_stock', 'in_use']), # Adjust status values as per your Equipment model
    #     required=False,
    #     help_text="Select if this request is for an existing piece of equipment."
    # )

    class Meta:
        model = Request
        fields = [
            'subject', 
            'description', 
            'request_type', 
            'priority', # Added priority
            'related_equipment',
            'department_location',
            'desired_completion_date',
        ]
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }
        help_texts = {
            'related_equipment': 'Select if this request is for an existing piece of equipment that needs repair, upgrade, or replacement. Leave blank for new equipment requests where the specific model is not yet identified.',
            'request_type': 'Select the general category of your request.',
            'department_location': 'Specify the department or physical location for this request.',
            'desired_completion_date': 'Indicate your preferred date for the request to be completed.',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # You can further customize fields here if needed
        # For example, making request_type not required if it's truly optional at creation
        # self.fields['request_type'].required = False 
        
        # If you have a lot of equipment, consider using a widget that supports searching,
        # like django-select2 or django-autocomplete-light for 'related_equipment'.
        # For now, default ModelChoiceField will be a dropdown.

        # Ensure RequestType queryset is ordered or filtered if necessary
        self.fields['request_type'].queryset = RequestType.objects.order_by('name')
