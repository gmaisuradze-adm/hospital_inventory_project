from django.db import models
from django.conf import settings
from inventory.models import Equipment # Assuming this is your equipment model
from django.utils import timezone

class RequestType(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Request Type"
        verbose_name_plural = "Request Types"
        # ordering = ['name'] # Optional: if you want them ordered by name

class Request(models.Model):
    STATUS_CHOICES = [
        ('new', 'New'),                         # Newly submitted by any staff
        ('assigned', 'Assigned'),               # Claimed by IT staff
        ('pending_order', 'Pending Order'),     # Item needs to be ordered
        ('completed', 'Completed'),             # Request fulfilled
        ('rejected', 'Rejected'),               # Request denied
        ('on_hold', 'On Hold'),                 # Optionally, if work is paused
        # ('cancelled', 'Cancelled'),           # Optionally, if a request can be cancelled
    ]
    PRIORITY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('critical', 'Critical'),
    ]

    subject = models.CharField(max_length=255)
    description = models.TextField(help_text="Detailed description of the request or reason for request.") # Clarified help_text
    request_type = models.ForeignKey(
        RequestType, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, # Making it blank=True if type is not always mandatory initially
        related_name='requests'
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='new') # Default to 'new'
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default='medium')
    
    requested_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE, 
        related_name='submitted_requests'
    )
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        related_name='assigned_requests',
        limit_choices_to={'is_staff': True} # Suggestion: Only staff can be assigned
    )
    
    related_equipment = models.ForeignKey(
        Equipment, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        related_name='maintenance_requests',
        help_text="Select if this request is for an existing piece of equipment (e.g., upgrade/repair)."
    )
    
    # NEW OR UPDATED FIELDS BASED ON WORKFLOW
    department_location = models.CharField(
        max_length=150, 
        blank=True, # Can be optional if not always known or applicable
        help_text="Department or location requiring the equipment."
    )
    desired_completion_date = models.DateField(
        null=True, 
        blank=True, # Making it optional as per "desired"
        help_text="Desired completion date (deadline)."
    )
    
    created_at = models.DateTimeField(default=timezone.now, verbose_name="Date Submitted") # Renamed for clarity
    date_assigned = models.DateTimeField(null=True, blank=True, verbose_name="Date Assigned")
    # resolved_at will be used as 'Date Completed'
    resolved_at = models.DateTimeField(null=True, blank=True, verbose_name="Date Completed/Resolved")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Last Updated") # Tracks any model save

    resolution_notes = models.TextField(blank=True, null=True, help_text="Notes on how the request was resolved or why it was rejected.")

    def get_status_badge_class(self):
        # Adjusted to new status keys
        if self.status == 'new':
            return 'secondary'
        elif self.status == 'assigned':
            return 'info text-dark'
        elif self.status == 'pending_order':
            return 'warning text-dark'
        elif self.status == 'completed':
            return 'success'
        elif self.status == 'rejected':
            return 'danger'
        elif self.status == 'on_hold':
            return 'secondary'
        # elif self.status == 'cancelled':
        #     return 'dark'
        return 'light text-dark' 

    def __str__(self):
        return f"REQ-{self.id}: {self.subject} ({self.get_status_display()})"

    class Meta:
        ordering = ['-created_at']
        verbose_name = "IT Equipment Request"
        verbose_name_plural = "IT Equipment Requests"

class RequestUpdate(models.Model):
    request = models.ForeignKey(Request, on_delete=models.CASCADE, related_name='updates')
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    update_time = models.DateTimeField(default=timezone.now)
    notes = models.TextField()
    # Storing old and new status as their string values for logging
    old_status = models.CharField(max_length=50, blank=True, null=True)
    new_status = models.CharField(max_length=50, blank=True, null=True)

    # You might want to log other specific field changes here if needed

    def __str__(self):
        return f"Update for {self.request} at {self.update_time.strftime('%Y-%m-%d %H:%M')}"

    class Meta:
        ordering = ['-update_time']
        verbose_name = "Request Update Log"
        verbose_name_plural = "Request Update Logs"
