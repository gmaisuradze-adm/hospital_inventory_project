# Version: 1.2 - 2025-05-26 13:41:05 UTC - gmaisuradze-adm
# - Added category filtering to EquipmentListView.
# - Added 'categories' to EquipmentListView context for dropdown filter.
# - Ensured other views remain as previously defined by user.

from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.contrib.messages.views import SuccessMessageMixin
from django.contrib import messages
from .models import Equipment, Category, Status, Location, Supplier
from .forms import EquipmentForm, CategoryForm, StatusForm, LocationForm, SupplierForm

# Equipment Views
class EquipmentListView(LoginRequiredMixin, ListView):
    model = Equipment
    template_name = 'inventory/equipment_list.html'
    context_object_name = 'equipment_list'
    paginate_by = 15

    def get_queryset(self):
        queryset = super().get_queryset().select_related(
            'category', 'status', 'current_location', 'assigned_to', 'supplier'
        )
        
        # Filtering by category
        category_id_str = self.request.GET.get('category') # Get as string
        if category_id_str and category_id_str.isdigit(): # Check if it's not empty and is a digit
            queryset = queryset.filter(category_id=int(category_id_str))
            
        return queryset.order_by('name') # Order by name after potential filtering

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Equipment Inventory"
        # Add categories for the filter dropdown
        context['categories'] = Category.objects.all().order_by('name')
        return context

class EquipmentDetailView(LoginRequiredMixin, DetailView):
    model = Equipment
    template_name = 'inventory/equipment_detail.html'
    context_object_name = 'equipment'

    def get_queryset(self):
        return super().get_queryset().select_related(
            'category', 'status', 'current_location', 'assigned_to', 
            'supplier', 'added_by', 'updated_by'
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f"{self.object.name} Details"
        # Add related data like maintenance history if needed
        return context

class EquipmentCreateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, CreateView):
    model = Equipment
    form_class = EquipmentForm
    template_name = 'inventory/equipment_form.html'
    permission_required = 'inventory.add_equipment'
    success_url = reverse_lazy('inventory:equipment_list')
    success_message = "Equipment '%(name)s' was created successfully."

    def form_valid(self, form):
        form.instance.added_by = self.request.user
        form.instance.updated_by = self.request.user
        return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Add New Equipment"
        context['form_title'] = "Create Equipment Item"
        context['submit_button_text'] = "Create Equipment"
        return context

class EquipmentUpdateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, UpdateView):
    model = Equipment
    form_class = EquipmentForm
    template_name = 'inventory/equipment_form.html'
    permission_required = 'inventory.change_equipment'
    success_message = "Equipment '%(name)s' was updated successfully."

    def form_valid(self, form):
        form.instance.updated_by = self.request.user
        # messages.info is not needed here if SuccessMessageMixin is doing its job for success_message
        return super().form_valid(form)

    def get_success_url(self):
        # Redirect to the detail view of the updated object
        return reverse_lazy('inventory:equipment_detail', kwargs={'pk': self.object.pk})

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f"Update {self.object.name}"
        context['form_title'] = f"Editing Equipment: {self.object.name}"
        context['submit_button_text'] = "Save Changes"
        return context

class EquipmentDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Equipment
    template_name = 'inventory/equipment_confirm_delete.html'
    permission_required = 'inventory.delete_equipment'
    success_url = reverse_lazy('inventory:equipment_list')
    context_object_name = 'equipment'

    def post(self, request, *args, **kwargs):
        equipment_name = self.get_object().name
        messages.success(self.request, f"Equipment '{equipment_name}' has been successfully deleted.")
        return super().post(request, *args, **kwargs)
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f"Confirm Delete: {self.object.name}"
        return context

# Category Views
class CategoryListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Category
    template_name = 'inventory/category_list.html'
    context_object_name = 'categories'
    permission_required = 'inventory.view_category'
    paginate_by = 10
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Equipment Categories"
        return context

class CategoryCreateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, CreateView):
    model = Category
    form_class = CategoryForm
    template_name = 'inventory/generic_form.html'
    permission_required = 'inventory.add_category'
    success_url = reverse_lazy('inventory:category_list')
    success_message = "Category '%(name)s' created successfully."
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Create New Category"
        context['form_title'] = "Add Category"
        context['submit_button_text'] = "Create Category"
        return context

class CategoryUpdateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, UpdateView):
    model = Category
    form_class = CategoryForm
    template_name = 'inventory/generic_form.html'
    permission_required = 'inventory.change_category'
    success_url = reverse_lazy('inventory:category_list')
    success_message = "Category '%(name)s' updated successfully."
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f"Update Category: {self.object.name}"
        context['form_title'] = f"Edit Category: {self.object.name}"
        context['submit_button_text'] = "Save Changes"
        return context

class CategoryDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView): # SuccessMessageMixin not typical here
    model = Category
    template_name = 'inventory/generic_confirm_delete.html'
    permission_required = 'inventory.delete_category'
    success_url = reverse_lazy('inventory:category_list')
    context_object_name = 'object_to_delete' # Renamed for clarity in generic_confirm_delete
    
    def post(self, request, *args, **kwargs):
        object_name = self.get_object().name
        response = super().post(request, *args, **kwargs)
        messages.success(self.request, f"Category '{object_name}' has been deleted.")
        return response

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f"Confirm Delete: {self.object.name}"
        context['type_of_object'] = "Category" # For generic_confirm_delete template
        return context


# Status Views
class StatusListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Status
    template_name = 'inventory/status_list.html'
    context_object_name = 'statuses'
    permission_required = 'inventory.view_status'
    paginate_by = 10
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Equipment Statuses"
        return context

class StatusCreateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, CreateView):
    model = Status
    form_class = StatusForm
    template_name = 'inventory/generic_form.html'
    permission_required = 'inventory.add_status'
    success_url = reverse_lazy('inventory:status_list')
    success_message = "Status '%(name)s' created successfully."
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Create New Status"
        context['form_title'] = "Add Status"
        context['submit_button_text'] = "Create Status"
        return context

class StatusUpdateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, UpdateView):
    model = Status
    form_class = StatusForm
    template_name = 'inventory/generic_form.html'
    permission_required = 'inventory.change_status'
    success_url = reverse_lazy('inventory:status_list')
    success_message = "Status '%(name)s' updated successfully."
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f"Update Status: {self.object.name}"
        context['form_title'] = f"Edit Status: {self.object.name}"
        context['submit_button_text'] = "Save Changes"
        return context

class StatusDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Status
    template_name = 'inventory/generic_confirm_delete.html'
    permission_required = 'inventory.delete_status'
    success_url = reverse_lazy('inventory:status_list')
    context_object_name = 'object_to_delete'

    def post(self, request, *args, **kwargs):
        object_name = self.get_object().name
        response = super().post(request, *args, **kwargs)
        messages.success(self.request, f"Status '{object_name}' has been deleted.")
        return response

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f"Confirm Delete: {self.object.name}"
        context['type_of_object'] = "Status"
        return context


# Location Views
class LocationListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Location
    template_name = 'inventory/location_list.html'
    context_object_name = 'locations'
    permission_required = 'inventory.view_location'
    paginate_by = 10
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Locations"
        return context

class LocationCreateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, CreateView):
    model = Location
    form_class = LocationForm
    template_name = 'inventory/generic_form.html'
    permission_required = 'inventory.add_location'
    success_url = reverse_lazy('inventory:location_list')
    success_message = "Location '%(name)s' created successfully."
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Create New Location"
        context['form_title'] = "Add Location"
        context['submit_button_text'] = "Create Location"
        return context

class LocationUpdateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, UpdateView):
    model = Location
    form_class = LocationForm
    template_name = 'inventory/generic_form.html'
    permission_required = 'inventory.change_location'
    success_url = reverse_lazy('inventory:location_list')
    success_message = "Location '%(name)s' updated successfully."
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f"Update Location: {self.object.name}"
        context['form_title'] = f"Edit Location: {self.object.name}"
        context['submit_button_text'] = "Save Changes"
        return context

class LocationDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Location
    template_name = 'inventory/generic_confirm_delete.html'
    permission_required = 'inventory.delete_location'
    success_url = reverse_lazy('inventory:location_list')
    context_object_name = 'object_to_delete'

    def post(self, request, *args, **kwargs):
        object_name = self.get_object().name
        response = super().post(request, *args, **kwargs)
        messages.success(self.request, f"Location '{object_name}' has been deleted.")
        return response

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f"Confirm Delete: {self.object.name}"
        context['type_of_object'] = "Location"
        return context


# Supplier Views
class SupplierListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Supplier
    template_name = 'inventory/supplier_list.html'
    context_object_name = 'suppliers'
    permission_required = 'inventory.view_supplier'
    paginate_by = 10
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Suppliers"
        return context

class SupplierCreateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, CreateView):
    model = Supplier
    form_class = SupplierForm
    template_name = 'inventory/generic_form.html'
    permission_required = 'inventory.add_supplier'
    success_url = reverse_lazy('inventory:supplier_list')
    success_message = "Supplier '%(name)s' created successfully."
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Create New Supplier"
        context['form_title'] = "Add Supplier"
        context['submit_button_text'] = "Create Supplier"
        return context

class SupplierUpdateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, UpdateView):
    model = Supplier
    form_class = SupplierForm
    template_name = 'inventory/generic_form.html'
    permission_required = 'inventory.change_supplier'
    success_url = reverse_lazy('inventory:supplier_list')
    success_message = "Supplier '%(name)s' updated successfully."
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f"Update Supplier: {self.object.name}"
        context['form_title'] = f"Edit Supplier: {self.object.name}"
        context['submit_button_text'] = "Save Changes"
        return context

class SupplierDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Supplier
    template_name = 'inventory/generic_confirm_delete.html'
    permission_required = 'inventory.delete_supplier'
    success_url = reverse_lazy('inventory:supplier_list')
    context_object_name = 'object_to_delete'
    
    # Typo in original post: 'aargs' corrected to 'args'
    def post(self, request, *args, **kwargs): 
        object_name = self.get_object().name
        response = super().post(request, *args, **kwargs)
        messages.success(self.request, f"Supplier '{object_name}' has been deleted.")
        return response

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f"Confirm Delete: {self.object.name}"
        context['type_of_object'] = "Supplier"
        return context