# Version: 1.1 - 2025-05-26 10:05:27 UTC - gmaisuradze-adm - Restored lookup models and added get_absolute_url to Equipment
from django.db import models
from django.conf import settings
from django.urls import reverse
from django.utils import timezone

class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)
    icon = models.CharField(max_length=50, blank=True, null=True, help_text="Font Awesome icon class (e.g., 'fa-laptop')")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Categories"
        ordering = ['name']

class Status(models.Model):
    name = models.CharField(max_length=50, unique=True)
    description = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=True, help_text="Is this status for active, usable equipment?")
    is_decommissioned = models.BooleanField(default=False, help_text="Is this status for decommissioned equipment?")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Statuses"
        ordering = ['name']

class Location(models.Model):
    name = models.CharField(max_length=100, unique=True)
    address = models.CharField(max_length=255, blank=True, null=True)
    floor = models.CharField(max_length=50, blank=True, null=True)
    room_number = models.CharField(max_length=50, blank=True, null=True)
    notes = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['name']

class Supplier(models.Model):
    name = models.CharField(max_length=150, unique=True)
    contact_person = models.CharField(max_length=100, blank=True, null=True)
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    website = models.URLField(blank=True, null=True)
    notes = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['name']

class Equipment(models.Model):
    name = models.CharField(max_length=200)
    asset_tag = models.CharField(max_length=50, unique=True, help_text="Unique identifier for the equipment")
    serial_number = models.CharField(max_length=100, blank=True, null=True, unique=True)
    
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, blank=True, related_name="equipment")
    status = models.ForeignKey(Status, on_delete=models.SET_NULL, null=True, blank=True, related_name="equipment")
    
    current_location = models.ForeignKey(Location, on_delete=models.SET_NULL, null=True, blank=True, related_name="equipment_at_location")
    assigned_to = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name="assigned_equipment")
    
    supplier = models.ForeignKey(Supplier, on_delete=models.SET_NULL, null=True, blank=True, related_name="supplied_equipment")
    purchase_date = models.DateField(null=True, blank=True)
    purchase_cost = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    warranty_expiry_date = models.DateField(null=True, blank=True)
    
    notes = models.TextField(blank=True, null=True)
    
    date_added = models.DateTimeField(default=timezone.now)
    added_by = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='added_equipment', on_delete=models.SET_NULL, null=True, blank=True)
    last_updated = models.DateTimeField(auto_now=True)
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='updated_equipment', on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return f"{self.name} ({self.asset_tag})"

    def get_absolute_url(self):
        return reverse('inventory:equipment_detail', kwargs={'pk': self.pk})

    class Meta:
        verbose_name = "Equipment Item"
        verbose_name_plural = "Equipment Items"
        ordering = ['name', 'asset_tag']