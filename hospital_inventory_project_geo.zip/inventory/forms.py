# Version: 1.0 - 2025-05-26 10:10:00 UTC - gmaisuradze-adm - Initial forms for inventory app
from django import forms
from .models import Equipment, Category, Status, Location, Supplier

class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name', 'description', 'icon']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }

class StatusForm(forms.ModelForm):
    class Meta:
        model = Status
        fields = ['name', 'description', 'is_active', 'is_decommissioned']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }

class LocationForm(forms.ModelForm):
    class Meta:
        model = Location
        fields = ['name', 'address', 'floor', 'room_number', 'notes']
        widgets = {
            'address': forms.Textarea(attrs={'rows': 2}),
            'notes': forms.Textarea(attrs={'rows': 3}),
        }

class SupplierForm(forms.ModelForm):
    class Meta:
        model = Supplier
        fields = ['name', 'contact_person', 'phone_number', 'email', 'website', 'notes']
        widgets = {
            'notes': forms.Textarea(attrs={'rows': 3}),
        }

class EquipmentForm(forms.ModelForm):
    class Meta:
        model = Equipment
        fields = [
            'name', 'asset_tag', 'serial_number', 
            'category', 'status', 
            'current_location', 'assigned_to',
            'supplier', 'purchase_date', 'purchase_cost', 'warranty_expiry_date',
            'notes'
        ]
        widgets = {
            'purchase_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'warranty_expiry_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'notes': forms.Textarea(attrs={'rows': 4, 'class': 'form-control'}),
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'asset_tag': forms.TextInput(attrs={'class': 'form-control'}),
            'serial_number': forms.TextInput(attrs={'class': 'form-control'}),
            'category': forms.Select(attrs={'class': 'form-select'}),
            'status': forms.Select(attrs={'class': 'form-select'}),
            'current_location': forms.Select(attrs={'class': 'form-select'}),
            'assigned_to': forms.Select(attrs={'class': 'form-select'}),
            'supplier': forms.Select(attrs={'class': 'form-select'}),
            'purchase_cost': forms.NumberInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Make assigned_to not required by the form, as the model allows null
        self.fields['assigned_to'].required = False 
        self.fields['serial_number'].required = False
        self.fields['supplier'].required = False
        self.fields['purchase_date'].required = False
        self.fields['purchase_cost'].required = False
        self.fields['warranty_expiry_date'].required = False
        self.fields['notes'].required = False
        self.fields['category'].required = False # Assuming category might not always be known initially
        self.fields['status'].required = False   # Assuming status might not always be known initially
        self.fields['current_location'].required = False # Assuming location might not always be known initially

        # If you are using crispy-forms and want to apply form-control to all:
        # for field_name, field in self.fields.items():
        #     if not isinstance(field.widget, (forms.CheckboxInput, forms.RadioSelect, forms.FileInput)):
        #         field.widget.attrs.update({'class': 'form-control'})